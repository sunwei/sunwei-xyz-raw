# X

Show X post in your markdown content.

## Example

```tpl
{{</* x user="SanDiegoZoo" id="1453110110599868418" /*/>}}
```

{{< x user="SanDiegoZoo" id="1453110110599868418" />}}
