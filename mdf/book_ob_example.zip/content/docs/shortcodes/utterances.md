# Utterances

Show Utterances comments in your markdown content.

## Example

```tpl
{{</* utterances repo="mdfriday/comments" issue="1" /*/>}}
```

{{< utterances repo="mdfriday/comments" issue="1" />}}
