# Movies

```dataview
TABLE title AS Movie, year AS Year, rating AS Rating, poster AS Poster
FROM #movie OR "ob plugins/obsidian/movies"
SORT rating DESC
```

