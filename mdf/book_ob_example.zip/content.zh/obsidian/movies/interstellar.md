---
title: Interstellar
year: 2014
rating: 9.1
poster: "![[interstellar.jpeg]]"
tags: [movie]
---

# Introduction

A mind-bending thriller directed by Christopher Nolan.
