---
title: Inception
year: 2010
rating: 9.0
poster: "![[inception.jpg]]"
tags: [movie]
---

# Introduction 

Once upon a midnight dreary, while I pondered, weak and weary, Over many a quaint and curious volume of forgotten lore—