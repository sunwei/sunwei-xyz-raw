---
title: The Matrix
year: 1999
rating: 9.2
poster: "![[matrix.jpeg]]"
tags: [movie]
---

# Introduction

Once upon a midnight dreary, while I pondered, weak and weary, Over many a quaint and curious volume of forgotten lore—