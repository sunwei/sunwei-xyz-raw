---
title: "MDFriday Slides"
description: "A MDFriday theme for creating presentations with Markdown."
logo: "images/github-logo.png"
---

# 📽️

# MDFriday Slides

A MDFriday theme for creating presentations with Markdown.

~ Theme made by [@dzello](https://joshed.io/) ~
