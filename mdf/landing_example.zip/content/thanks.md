---
title: "Thank You - DevBook"

author:
  name: "Xiaoying Riley"
  description: "A free Bootstrap 5 template for developers and programmers who want to self-publish books."
  logo: "images/site-logo.svg"
---

We'll send you a free preview of the book to your email address shortly. 
Please check your inbox (and spam folder) for the download link.