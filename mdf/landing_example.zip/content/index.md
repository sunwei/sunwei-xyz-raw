---
title: "DevBook - Bootstrap 5 Book/eBook Landing Page Template For Developers"
description: "A free Bootstrap 5 template for developers and programmers who want to self-publish books. Download now and start selling your book right away!"

author:
  name: "Xiaoying Riley"
  description: "A free Bootstrap 5 template for developers and programmers who want to self-publish books."
  logo: "images/site-logo.svg"
  copyright: "Designed with ❤️ by Xiaoying Riley for developers"

---

{{% hero headline="Free Book & eBook<br>Landing Page Template" subheadline="A free Bootstrap 5 template for developers and programmers who want to self-publish books. Download now and start selling your book right away!" book_cover="images/devbook-cover.png" badge="New<br>Release" reviews_link="#reviews-section" reviews_text="See all book reviews" %}}

{{% hero-cta %}}
{{% hero-button text="Buy for $39" url="https://themes.3rdwavemedia.com/bootstrap-templates/startup/devbook-free-bootstrap-5-book-ebook-landing-page-template-for-developers/" class="btn-primary" /%}}
{{% hero-button text="Learn More" url="#benefits-section" class="btn-secondary scrollto" /%}}
{{% /hero-cta %}}

{{% hero-quotes count="3" %}}
{{% hero-quote name="James Doe" title="Co-Founder, Startup Week" profile="images/profiles/profile-1.png" active="true" %}}
Excellent Book! Add your book reviews here consectetur adipiscing elit. Aliquam euismod nunc porta urna facilisis tempor. Praesent mauris neque, viverra quis erat vitae, auctor imperdiet nisi.
{{% /hero-quote %}}
{{% hero-quote name="Jean Doe" title="Co-Founder, Startup Week" profile="images/profiles/profile-2.png" %}}
Highly recommended consectetur adipiscing elit. Proin et auctor dolor, sed venenatis massa. Vestibulum ullamcorper lobortis nisi non placerat praesent mauris neque
{{% /hero-quote %}}
{{% hero-quote name="Andy Doe" title="Frontend Developer, Company Lorem" profile="images/profiles/profile-3.png" %}}
Awesome! Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam euismod nunc porta urna facilisis tempor. Praesent mauris neque, viverra quis erat vitae.
{{% /hero-quote %}}
{{% /hero-quotes %}}

{{% /hero %}}

{{% benefits title="What Will You Get From This Book?" intro="Section intro goes here. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer blandit consequat consequat. Orci varius natoque penatibus et magnis." %}}

{{% benefit icon="fas fa-laptop-code" heading="Build Lorem Ipsum lobortis nec mauris habitant morbi" %}}
List one of your book's benefits here. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer blandit consequat consequat.
{{% /benefit %}}

{{% benefit icon="fa-brands fa-js-square" heading="Learn from lorem ipsum dolor sit amet consectetur" %}}
List one of your book's benefits here. Orci varius natoque penatibus et magnis dis parturient montes.
{{% /benefit %}}

{{% benefit icon="fa-brands fa-rocketchat" heading="Discover phasellus id egestas tellus maximus" %}}
List one of your book's benefits here. Orci varius natoque penatibus et magnis dis parturient montes.
{{% /benefit %}}

{{% benefit icon="fa-brands fa-angular" heading="Master aliquet augue ac ipsum lobortis interdum" %}}
List one of your book's benefits here. Orci varius natoque penatibus et magnis dis parturient montes.
{{% /benefit %}}

{{% benefit icon="fas fa-code-branch" heading="Deploy elementum mauris tincidunt tempus sagittis" %}}
List one of your book's benefits here. Orci varius natoque penatibus et magnis dis parturient montes.
{{% /benefit %}}

{{% benefit icon="fas fa-hand-holding-usd" heading="Become mattis est et mauris tempus non imperdiet" %}}
List one of your book's benefits here. Orci varius natoque penatibus et magnis dis parturient montes.
{{% /benefit %}}

{{% /benefits %}}

{{< content-showcase title="What's Included" image="images/devbook-devices.png" cta_text="I want this book" cta_url="https://themes.3rdwavemedia.com/bootstrap-templates/startup/devbook-free-bootstrap-5-book-ebook-landing-page-template-for-developers/" >}}

{{< content-point >}}List your book's content here.{{< /content-point >}}
{{< content-point >}}PDF fermentum tincidunt erat.{{< /content-point >}}
{{< content-point >}}EPUB curabitur fermentum.{{< /content-point >}}
{{< content-point >}}Lorem ipsum dolor sit amet.{{< /content-point >}}
{{< content-point >}}Praesent molestie odio risus.{{< /content-point >}}
{{< content-point >}}Kindle curabitur fermentum.{{< /content-point >}}
{{< content-point >}}Kindle curabitur fermentum.{{< /content-point >}}
{{< content-point >}}Kindle curabitur fermentum.{{< /content-point >}}

{{< /content-showcase >}}

{{% audience title="Who This Book Is For" intro="List your target readers in this section and back up with reviews. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin sodales sit amet neque sit amet molestie. Vivamus hendrerit nisi condimentum erat tempus, vitae accumsan odio euismod." %}}

{{% audience-item title="Software Developers" %}}
Learn lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin sodales sit amet neque sit amet molestie.
{{% /audience-item %}}

{{% audience-item title="App Developers" %}}
Learn lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin sodales sit amet neque sit amet molestie.
{{% /audience-item %}}

{{% audience-item title="Web Developers" %}}
Learn lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin sodales sit amet neque sit amet molestie.
{{% /audience-item %}}

{{% audience-item title="Product Designers" %}}
Learn lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin sodales sit amet neque sit amet molestie.
{{% /audience-item %}}

{{% /audience %}}

{{% reviews title="Book Reviews" intro="See what our readers are saying." %}}

{{% review name="James Doe" title="Co-Founder, Startup Week" profile="images/profiles/profile-1.png" %}}
Excellent Book! Add your book review here consectetur adipiscing elit. Aliquam euismod nunc porta urna facilisis tempor.
{{% /review %}}

{{% review name="Jean Doe" title="Co-Founder, Company Tristique" profile="images/profiles/profile-2.png" %}}
Great Book! Add your book review here consectetur adipiscing elit. Aliquam euismod nunc porta urna facilisis tempor. Praesent mauris neque.
{{% /review %}}

{{% review name="Tom Doe" title="Product Designer, Company Lorem" profile="images/profiles/profile-3.png" %}}
Excellent Book! Add your book review here consectetur adipiscing elit. Pellentesque ac leo turpis. Phasellus imperdiet id ligula tempor imperdiet.
{{% /review %}}

{{% review name="Alice Doe" title="App Developer, Company Ipsum" profile="images/profiles/profile-4.png" %}}
Another book review here consectetur adipiscing elit. Pellentesque ac leo turpis. Phasellus imperdiet id ligula tempor imperdiet.
{{% /review %}}

{{% review name="Sam Doe" title="Co-Founder, Company Integer" profile="images/profiles/profile-5.png" %}}
Another book review here consectetur adipiscing elit. Pellentesque ac leo turpis. Phasellus imperdiet id ligula tempor imperdiet.
{{% /review %}}

{{% /reviews %}}

{{% lead-form title="Get A Free Preview" 
intro="Sign up to get a free preview of the book.<br>You can offer visitors free book previews to generate leads." 
action="https://formsubmit.co/e826a06d62e1cf81e8faa63f87626b18"
redirect="https://theme-landing.mdfriday.com/thanks.html"
placeholder="Your email" button_text="Send" /%}}

{{% author-bio title="About The Author" profile="images/profiles/author-profile.png" 
twitter="https://x.com/3rdwave_themes" github="https://github.com/xriley" 
medium="https://medium.com/@3rdwave_themes" website="https://themes.3rdwavemedia.com/" %}}

This book landing page template is made by product designer [Xiaoying Riley](http://themes.3rdwavemedia.com) for developers. 

You can use this template to self-publish and promote your book/ebook/digital product. 
You can easily use platforms such as [Gumroad](https://gumroad.com/) to handle your book payment and delivery.

This template also includes a simple **lead form** for collecting visitor emails.
To make it work, you just need to set the **action** attribute in the form to a valid form handling service (for example, [FormSubmit](https://formsubmit.co/)).
You can point the form’s action to your endpoint (e.g. **https://formsubmit.co/your@email.com**) and optionally specify a **redirect** attribute to redirect users after submission.
This allows you to start collecting email sign-ups for book previews or newsletters without any server-side code.

This template is **100% FREE** as long as you **keep the footer attribution link**.

{{% /author-bio %}}
