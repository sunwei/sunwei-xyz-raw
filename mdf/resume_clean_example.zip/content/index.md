---
title: "孙悟空 | 简历"

author:
    name: "孙悟空"
    position: "行政专员"
    gender: "男"
    age: "30岁"
    experience: "4年经验"
    location: "上海"
    email: "support@mdfriday.com"
    phone: "15388888880"
    avatar: "avatar.webp"
---

{{% education %}}
{{% school period="2016-09 ~ 2018-07" school="个人简历商学院" degree="工商管理（硕士）" %}}
专业成绩：GPA 3.8/4（专业前3%）<br>
主修课程：战略管理、组织行为学、财务管理、市场营销、运营管理、商业伦理、领导力发展、创新管理等。
{{% /school %}}
{{% school period="2012-09 ~ 2016-07" school="个人简历师范大学" degree="工商管理（本科）" %}}
专业成绩：GPA 3.66/4（专业前5%）<br>
主修课程：基础会计学、统计学、经济法概论、财务会计学、管理学原理、市场营销学、人力资源管理学等。
{{% /school %}}
{{% /education %}}

{{% experience %}}
{{% work period="2018-09 ~ 至今" company="个人简历网科技有限公司" position="行政专员" %}}
- 负责行政事务与人事管理，协助公司规章制度的落实与执行。
- 负责文件审核、会议组织及档案管理。
- 组织公司活动，推动员工关系与企业文化建设。
{{% /work %}}

{{% work period="2016-09 ~ 2018-08" company="上海馨馨网络科技有限公司" position="行政专员" %}}
- 负责日常行政工作及物资采购。
- 组织招聘与培训工作，协助公司活动策划与执行。
{{% /work %}}
{{% /experience %}}

{{% section title="技能特长" %}}
- 语言能力：大学英语6级证书，获全国大学生英语竞赛一等奖，具备良好的听说读写能力。
- 计算机：熟练使用 Windows 办公软件，Word、Excel、PowerPoint 等。
- 团队协作：具备较强的沟通与协作能力。
- 计算机：精通
- 英语：良好
{{% /section %}}

{{% section title="荣誉证书" %}}
- 英语四级，听说读写能力良好，能熟练进行日常交流。
- 全国计算机一级证书，熟练应用 Office 办公软件。
{{% /section %}}

{{% section title="自我评价" %}}
工作认真负责，勤奋好学，具备较强的学习与分析能力，能够独立发现问题并提出解决方案，积极进取，勇于挑战新任务。
{{% /section %}}
