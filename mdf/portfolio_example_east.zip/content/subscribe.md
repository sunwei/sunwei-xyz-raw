---
title: Join Us
description: 'I run an group for people interested in one person business. Join us to get updates, tips, and resources.'
author: Sun Wei
---

{{% lead-form title="Get A Free Preview"
intro="Sign up to get a free preview of the book.<br>You can offer visitors free book previews to generate leads."
action="https://formsubmit.co/hello@gmail.com"
redirect="http://localhost:8091/public/thanks.html"
placeholder="Your email" button_text="Subscribe" /%}}