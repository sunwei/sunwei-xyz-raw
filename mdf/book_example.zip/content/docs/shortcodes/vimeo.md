# Vimeo

Show Vimeo video in your markdown content.

## Example

```tpl
{{</* vimeo 55073825 /*/>}}
```

{{< vimeo 55073825 />}}
