# Bilibili

Show Bilibili video in your markdown content.

## Example

```tpl
{{</* bilibili BV1LVttzxEqL /*/>}}
```

{{< bilibili BV1LVttzxEqL />}}
