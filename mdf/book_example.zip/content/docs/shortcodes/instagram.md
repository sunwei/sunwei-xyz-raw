# Instagram

Show Instagram post in your markdown content.

## Example

```tpl
{{</* instagram CxOWiQNP2MO /*/>}}
```

{{< instagram CxOWiQNP2MO />}}
