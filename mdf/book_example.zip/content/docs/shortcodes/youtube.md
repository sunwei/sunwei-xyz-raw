# Youtube

Show Youtube video in your markdown content.

## Example

```tpl
{{</* youtube 2maPgW5uDCI /*/>}}
```

{{< youtube 2maPgW5uDCI />}}
