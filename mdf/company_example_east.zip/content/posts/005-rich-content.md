---
author: Hugo Authors
title: Rich Content
date: 2023-02-09
description: A brief description of Hugo Shortcodes
feature: true
featured_image: "assets/images/featured/spacejam.jpg"
weight: 5
---

Hugo ships with several Built-in Shortcodes for rich content.
<!--more-->
---

# Bilibili

{{< bilibili id="BV1bqsfzbEmt" height="515" />}}

