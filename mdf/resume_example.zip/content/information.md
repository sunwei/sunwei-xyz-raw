---
title: "Additional Information"
---

{{% education %}}

{{% school name="University College London" from="2010" to="2011" major="MSc in Computer Science" %}}
{{% /school %}}

{{% school name="Imperial College London" from="2007" to="2010" major="BSc Maths and Physics" %}}
{{% /school %}}

{{% /education %}}

{{% skills %}}

{{% skill category="Technical" %}}

- JavaScript/Angular/React/Vue
- Python/Ruby/PHP
- Node.js/ASP.NET
- PostgreSQL/MySQL
- Object-oriented design
- Design and implement database structures
- Lead and deliver complex software systems
- 
{{% /skill %}}

{{% skill category="Professional" %}}

- Effective communication
- Team player
- Strong problem solver
- Good time management

{{% /skill %}}

{{% /skills %}}

{{% awards %}}

{{% award name="Award Lorem Ipsum" organization="Microsoft" date="2019" %}}
Outstanding contribution to lorem ipsum project.
{{% /award %}}

{{% award name="Award Donec Sodales" organization="Oracle" date="2017" %}}
Recognition for exceptional performance.
{{% /award %}}

{{% /awards %}}

{{% languages %}}

{{% language name="English" level="Native" /%}}
{{% language name="Spanish" level="Professional" /%}}
{{% language name="Chinese" level="Conversational" /%}}

{{% /languages %}}

{{% interests %}}

{{% interest name="Climbing" %}}
{{% /interest %}}
{{% interest name="Snowboarding" %}}
{{% /interest %}}
{{% interest name="Photography" %}}
{{% /interest %}}
{{% interest name="Travelling" %}}
{{% /interest %}}

{{% /interests %}}