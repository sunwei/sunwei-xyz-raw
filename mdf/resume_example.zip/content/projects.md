---
title: "Projects"
---

{{% project name="Project Lorem Ipsum" kind="Open Source" url="https://github.com/username/project1" %}}

You can use this section for your side projects. 
Lorem ipsum dolor sit amet, consectetuer adipiscing elit. 
Aenean commodo ligula eget dolor. Aenean massa. 
Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus.

{{% /project %}}

{{% project name="Project Sed Fringilla" kind="Open Source" %}}

You can use this section for your side projects. 
Cras dapibus. Vivamus elementum semper nisi. 
Aenean vulputate eleifend tellus. Aenean leo ligula, porttitor eu, consequat vitae, eleifend ac, enim.

{{% /project %}}

{{% project name="Project Praesent" kind="Commercial" %}}

You can use this section for your side projects. 
Cras dapibus. Vivamus elementum semper nisi. 
Aenean vulputate eleifend tellus. Aenean leo ligula, porttitor eu, consequat vitae, eleifend ac, enim.

{{% /project %}}