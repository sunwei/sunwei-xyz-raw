---
title: "Work Experience"
---

{{% work company="Google" title="Senior Software Engineer" from="2019" to="Present" %}}

Role description goes here ipsum dolor sit amet, consectetuer adipiscing elit. 
Aenean commodo ligula eget dolor. 
Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. 
Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem. 
Donec pede justo, fringilla vel. Lorem ipsum dolor sit amet, consectetuer adipiscing elit. 
Aenean commodo ligula eget dolor. Aenean massa. 
Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. 
Donec quam felis.

- Lorem ipsum dolor sit amet, consectetuer.
- Aenean commodo ligula eget dolor.
- Etiam ultricies nisi vel augue.

{{% /work %}}

{{% work company="Apple" title="Lead Software Developer" from="2016" to="2019" %}}

Role description goes here ipsum dolor sit amet, consectetuer adipiscing elit. 
Aenean commodo ligula eget dolor. Aenean massa. 
Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. 
Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem. 
Donec pede justo, fringilla vel.

- Lorem ipsum dolor sit amet, consectetuer.
- Aenean commodo ligula eget dolor.

{{% /work %}}

{{% work company="Dropbox" title="Senior Software Developer" from="2014" to="2016" %}}

Role description goes here ipsum dolor sit amet, consectetuer adipiscing elit. 
Aenean commodo ligula eget dolor. Aenean massa. 
Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus.

{{% /work %}}

