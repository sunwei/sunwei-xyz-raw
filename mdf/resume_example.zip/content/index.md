---
title: "Simon Doe | Resume"

author:
  name: "Simon Doe"
  description: "Senior Software Engineer"
  website: "www.yourwebsite.com"
  avatar: "avatar.png"
  contact:
    email: "simon.doe@yourwebsite.com"
    address: "New York"
    phone: "0123 4567 890"
    website: "https://yourwebsite.com"
  social:
    github: "https://github.com/username"
    twitter: "https://twitter.com/username"
    linkedin: "https://linkedin.com/in/username"
    facebook: "https://facebook.com/username"

---

Summarise your career here. Donec quam felis, ultricies nec, pellentesque eu. 
Lorem ipsum dolor sit amet, consectetuer adipiscing elit. 
Aenean commodo ligula eget dolor. Aenean massa. 
Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. 
Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem. 
Maecenas nec odio et ante tincidunt tempus. Donec vitae sapien ut libero venenatis faucibus. 
Nullam quis ante. Etiam sit amet orci eget eros faucibus tincidunt. 
Duis leo. Sed fringilla mauris sit amet nibh.
