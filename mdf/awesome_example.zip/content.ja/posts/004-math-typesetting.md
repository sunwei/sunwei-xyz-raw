---
author: Hugo著者チーム
title: 数式組版 - ブログ記事で数学記法を使用する
date: 2023-04-01
description: KaTeXを使用する簡単なガイド
weight: 4
---

この例では[KaTeX](https://katex.org/)を使用します。

**注意：** [サポートされているTeX関数](https://katex.org/docs/supported.html)のオンラインリファレンスは有用なリソースです。

### 例

- ブロック数式：

{{< katex display=true >}}
\varphi = 1+\frac{1} {1+\frac{1} {1+\frac{1} {1+\cdots} } }
{{< /katex >}}

- インライン数式：

  これはインライン多項式です：{{< katex >}}5x^2 + 2y -7{{< /katex >}}.
