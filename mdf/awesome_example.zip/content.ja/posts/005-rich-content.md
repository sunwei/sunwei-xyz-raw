---
author: Hugo著者チーム
title: リッチコンテンツ
date: 2023-02-09
description: Hugoショートコードの簡単な説明
weight: 5
---

Hugoには、リッチコンテンツ用の複数の[組み込みショートコード](https://gohugo.io/content-management/shortcodes/#use-hugos-built-in-shortcodes)と、[プライバシー設定](https://gohugo.io/about/hugo-and-gdpr/)、および様々なソーシャルメディア埋め込みの静的・JS不要バージョンを可能にするシンプルショートコードのセットが付属しています。
<!--more-->
---

## YouTubeプライバシー強化ショートコード

{{< youtube ZJthWmvUzzc />}}

<br>

---

## Twitterシンプルショートコード

{{< x user="DesignReviewed" id="1085870671291310081" />}}

<br>

---

## Vimeoシンプルショートコード

{{< vimeo 48912912 />}}
