---
title: コメント
date: 2023-05-02
description: MDFridayブログawesomeテーマでのコメント設定
comments: true
---

## コメント

このテーマはDisqusコメントをサポートしています

## コメントを有効にする

特定の投稿でコメントを有効にするには、フロントマターでパラメータ `comments` を `true` に設定してください。

    ```yaml
    ---
    title: 目次を有効にする方法
    date: 2023-05-02
    comments: true
    ---
    ```
