---
title: Markdown構文ガイド
date: 2023-02-11
author: MDFriday著者チーム
description: 基本的なMarkdown構文とHTML要素のフォーマットを紹介するサンプル記事。
weight: 3
isStarred: true
---

## 見出し

以下のHTML `<h1>`—`<h6>` 要素は、6つのレベルのセクション見出しを表します。`<h1>` が最高のセクションレベルで、`<h6>` が最低です。

# H1

## H2

### H3

#### H4

##### H5

###### H6

## 段落

Xerum、quo qui aut unt expliquam qui dolut labo。Aque venitatiusda cum、voluptionse latur sitiae dolessi aut parist aut dollo enim qui voluptate ma dolestendit peritin re plis aut quas inctum laceat est volestemque commosa as cus endigna tectur、offic to cor sequas etum rerum idem sintibus eiur？Quianimin porecus evelectur、cum que nis nust voloribus ratem aut omnimi、sitatur？Quiatem。Nam、omnis sum am facea corem alique molestrunt et eos evelece arcillit ut aut eos eos nus、sin conecerem erum fuga。Ri oditatquam、ad quibus unda veliamenimin cusam et facea ipsamus es exerum sitate dolores editium rerore eost、temped molorro ratiae volorro te reribus dolorer sperchicium faceata tiustia prat。

Itatur？Quiatae cullecum rem ent aut odis in re eossequodi nonsequ idebis ne sapicia is sinveli squiatum、core et que aut hariosam ex eat。

## 画像

以下の構文を使用して画像を含めることができます。画像のパスは `index.md` ファイルに対して相対的である必要があります。

```markdown
![風景](1.jpg)
```

![風景](1.jpg)

外部ソースからの画像も含めることができます。

```markdown
![画像](https://picsum.photos/600/300)
```

![画像](https://picsum.photos/600/300)

## 引用

blockquote要素は、他のソースから引用されたコンテンツを表し、オプションで `footer` または `cite` 要素内にある引用と、注釈や略語などのインラインの変更を含む場合があります。

### 帰属なしの引用

> 引用内では、**太字**、_斜体_、[リンク](https://gohugo.io/)、`コード`などのMarkdown構文を使用できます。

### 帰属ありの引用

> メモリを共有することで通信するのではなく、通信することでメモリを共有せよ。<br>
> — <cite>Rob Pike[^1]</cite>

[^1]: 上記の引用は、2015年11月18日のGopherfestでのRob Pikeの[講演](https://www.youtube.com/watch?v=PAAkCSZUG1c)から抜粋されています。

## 表

### 表内のMarkdown

| 斜体   | 太字     | コード   |
| --------  | -------- | ------ |
| *斜体* | **太字** | `コード` |

## コードブロック

### バッククォートを使用したコードブロック

```html
<!doctype html>
<html lang="ja">
<head>
  <meta charset="utf-8">
  <title>HTML5文書の例</title>
</head>
<body>
  <p>テスト</p>
</body>
</html>
```

### 4つのスペースでインデントされたコードブロック

    <!doctype html>
    <html lang="ja">
    <head>
      <meta charset="utf-8">
      <title>HTML5文書の例</title>
    </head>
    <body>
      <p>テスト</p>
    </body>
    </html>

### インラインコード

バッククォートを使用して文中で `変数` を参照します。

## リストタイプ

### 順序付きリスト

1. 最初の項目
2. `コード`を含む2番目の項目
3. 3番目の項目

### 順序なしリスト

* リスト項目
* `コード`を含む別の項目
* さらに別の項目

### ネストされたリスト

* 果物
  * りんご
  * オレンジ
  * バナナ
* 乳製品
  * 牛乳
  * チーズ

## その他の要素 — abbr、sub、sup、kbd、mark

<abbr title="Graphics Interchange Format">GIF</abbr> はビットマップ画像フォーマットです。

H<sub>2</sub>O

X<sup>n</sup> + Y<sup>n</sup> = Z<sup>n</sup>

<kbd>CTRL</kbd>+<kbd>ALT</kbd>+<kbd>Delete</kbd> を押してセッションを終了します。

ほとんどの <mark>サンショウウオ</mark> は夜行性で、昆虫、ミミズ、その他の小さな生き物を狩ります。
