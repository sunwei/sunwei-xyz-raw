---
title: 概要
description: 'MDFridayの創設者、孫偉についてもっと詳しく。'
author: 孫偉
---

# 私について

こんにちは、**孫偉**です。  
**MDFriday**の創設者兼開発者です。

私の使命は、クリエイターが簡単に作品を公開できるようにすることです —  
デプロイメント、デザイン、設定に気を取られることなく。

**あなたはMarkdownを書くだけ。残りは私にお任せください。**

- 💡 Markdownとデザインに情熱を注いでいます
- 🧠 AIとクリエイティブコンテンツシステムを探求
- 🧰 GitHub: [Obsidian Fridayプラグイン](https://github.com/mdfriday/obsidian-friday-plugin)
- 🌐 プロジェクトサイト: [MDFriday](https://mdfriday.com)
