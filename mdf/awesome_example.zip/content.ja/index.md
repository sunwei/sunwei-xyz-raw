---
title: "ホーム"

menu:
  nav:
    - title: "ホーム"
      url: "ja"
      weight: 1
    - title: "記事"
      url: "ja/posts"
      weight: 2
    - title: "概要"
      url: "ja/about.html"
      weight: 3

organization:
  name: "MDFriday Inc."
  description: "MDFridayは強力なMarkdownエディターとノートアプリです。"
  vision: "創作に集中し、MDFridayがあなたのサイトを輝かせます。"
  website: "https://mdfriday.com"
  logo: "/images/logo.png"
  contact:
    email: "team@mdfriday.org"
    address: "リモート、グローバル"
    phone: "+1-202-555-0100"
  social:
    github: "https://github.com/mdfriday"
    twitter: "https://twitter.com/mdfriday"

author:
  name: "孫偉"
  description: "MDFridayの創設者、Markdown、AI、知識の可視化に情熱を注いでいます。"
  website: "https://sunwei.xyz"
  avatar: "avatar.png"
  contact:
    email: "sunwei@mdfriday.org"
    address: "リモート、グローバル"
    phone: "+1-202-555-0101"
  social:
    website: "https://yourwebsite.com"
    email: "mailto:youremail@domain.com"
    facebook: "https://facebook.com/username"
    github: "https://github.com/username"
    gitlab: "https://gitlab.com/username"
    bitbucket: "https://bitbucket.org/username"
    twitter: "https://twitter.com/username"
    reddit: "https://reddit.com/user/username"
    linkedin: "https://linkedin.com/in/username"
    xing: "https://www.xing.com/profile/username"
    stackoverflow: "https://stackoverflow.com/users/XXXXXXX/username"
    snapchat: "https://www.snapchat.com/add/username"
    instagram: "https://instagram.com/username"
    youtube: "https://youtube.com/user/username"
    soundcloud: "https://soundcloud.com/username"
    spotify: "https://open.spotify.com/user/username"
    bandcamp: "https://username.bandcamp.com"
    itchio: "https://username.itch.io"
    vk: "https://vk.com/username"
    paypal: "https://paypal.me/username"
    telegram: "https://t.me/username"
    500px: "https://500px.com/username"
    codepen: "https://codepen.io/username"
    mastodon: "https://mastodon.social/@username"   # インスタンスに応じて置き換える必要があります
    kaggle: "https://kaggle.com/username"
    weibo: "https://weibo.com/username"
    slack: "https://username.slack.com"
    medium: "https://medium.com/@username"
    discord: "https://discord.gg/XXXXXXX"
    strava: "https://www.strava.com/athletes/userid"
    lastfm: "https://last.fm/user/username"
    bluesky: "https://bsky.app/profile/username"


---

ライトモードとダークモードをサポートする、高速でミニマルなMDFridayテーマ。個人サイトやブログの運営に最適です。
