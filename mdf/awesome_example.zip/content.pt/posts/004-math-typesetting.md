---
author: Equipe de autores Hugo
title: Composição matemática - usar notação matemática em posts de blog
date: 2023-04-01
description: Um guia breve para usar KaTeX
weight: 4
---

Neste exemplo usaremos [KaTeX](https://katex.org/).

**Nota:** A referência online de
[Funções TeX Suportadas](https://katex.org/docs/supported.html) é um recurso útil.

### Exemplos

- Matemática em bloco:

{{< katex display=true >}}
\varphi = 1+\frac{1} {1+\frac{1} {1+\frac{1} {1+\cdots} } }
{{< /katex >}}

- Matemática inline:

  Este é um polinômio inline: {{< katex >}}5x^2 + 2y -7{{< /katex >}}.
