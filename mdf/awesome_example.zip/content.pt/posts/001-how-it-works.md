---
title: Como o MDFriday funciona?
date: 2025-10-10
author: Sun Wei
description: Guia de uso do MDFriday no Obsidian
weight: 1
tags:
  - MDFriday
---

**MDFriday** — Apenas escreva. MDFriday dá vida às suas palavras.

## A história do tema Awesome

Awesome é para criadores que veem através do ruído —
aqueles que querem que suas palavras falem,
não que seu design grite.

Simples. Limpo. Precisão mortal.
Isso é Awesome.

Como *John Wick* - "Sim, acho que estou de volta."

---

## ⚙️ Início rápido

1. Abra os **Plugins da Comunidade do Obsidian**
2. Procure por **Friday** e instale
3. Escolha um tema no painel MDFriday
4. Baixe as notas de exemplo do tema
5. Clique com o botão direito em uma nota → **Publicar na Web**
6. Clique em **Visualizar** para vê-lo ao vivo localmente

Após visualizar, edite as notas de exemplo com seu próprio conteúdo —
e você terá seu site pessoal!

Você pode:
- Exportar o site estático e enviá-lo para qualquer lugar
- Ou configurar as definições da nuvem para **publicar diretamente** com um clique

---

## 🧩 Visão geral da arquitetura

MDFriday consiste em três partes principais:

1. **Plugin Obsidian**
    - Fornece a interface de edição e gerenciamento de temas
    - Suporta visualização, exportação e publicação
    - Permite aos usuários instalar temas e notas de exemplo com um clique

2. **Motor de renderização de shortcodes**
    - Um sistema leve de templates estilo Hugo
    - Permite incorporação de componentes visuais personalizados (cartões, galerias, etc.)
    - Implementado em TypeScript, compatível entre plataformas

3. **Sistema de construção e publicação**
    - Converte Markdown + Shortcodes → site HTML estático
    - Aplica automaticamente o tema selecionado (Tailwind + motor de template)
    - Exporta arquivos prontos para hospedagem
    - Publicação na nuvem opcional (Cloudflare / GitHub Pages / personalizado)

---

## 🧠 Fluxo de trabalho

1. **Escrever Markdown**  
   Criar e editar notas no Obsidian — shortcodes incluídos.

2. **Escolher um tema**  
   Cada tema contém templates, notas de exemplo e recursos de estilo.  
   Os temas são totalmente personalizáveis e fáceis de visualizar.

3. **Visualizar e construir**  
   Clique em **Visualizar** para ver seu site localmente.  
   MDFriday renderiza Markdown + Shortcodes + Tema perfeitamente.

4. **Publicar**
    - Exportar o site estático e enviá-lo para qualquer lugar
    - Ou configurar credenciais da nuvem para publicação com um clique
    - Inclui automaticamente tags meta SEO e dados OpenGraph

---

## 🔧 Stack tecnológico e princípios de design

| Módulo | Tecnologia | Princípio de design |
|--------|-------------|------------------|
| Editor | Obsidian | Criação centralizada e sem distrações |
| Renderizador | TypeScript (compatível com `text/template`) | Consistência e extensibilidade |
| Estilização | Tailwind CSS | Minimal e temático |
| Construção | Node.js / ESBuild | Rápido e modular |
| Implantação | Cloudflare / GitHub Pages / Local | Flexível e controlado pelo usuário |

---

## 🪄 Tudo começa com Markdown

MDFriday não requer nenhuma nova sintaxe ou ferramenta.  
Cada site começa com um simples arquivo `.md`.  
Os temas definem **a aparência**,  
Os shortcodes definem **a sensação**.

> ✨ Resumindo:  
> **Escrever Markdown → Renderizar → Construir → Publicar**  
> Sem código. Sem configuração. Sem distrações.

---

## 👨‍💻 Uma palavra do autor

> "MDFriday é construído para crescer com os criadores —  
> de uma única nota a um site de marca pessoal.  
> Quero ajudá-lo a transformar seu conteúdo em ativos digitais."
>
> — Sun Wei
