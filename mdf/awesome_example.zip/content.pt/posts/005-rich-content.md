---
author: Equipe de autores Hugo
title: Conteúdo rico
date: 2023-02-09
description: Uma breve descrição dos shortcodes Hugo
weight: 5
---

Hugo vem com vários [Shortcodes integrados](https://gohugo.io/content-management/shortcodes/#use-hugos-built-in-shortcodes) para conteúdo rico, junto com uma [Configuração de privacidade](https://gohugo.io/about/hugo-and-gdpr/) e um conjunto de shortcodes simples que habilitam versões estáticas e sem JS de várias incorporações de mídia social.
<!--more-->
---

## Shortcode YouTube com privacidade aprimorada

{{< youtube ZJthWmvUzzc />}}

<br>

---

## Shortcode Twitter simples

{{< x user="DesignReviewed" id="1085870671291310081" />}}

<br>

---

## Shortcode Vimeo simples

{{< vimeo 48912912 />}}
