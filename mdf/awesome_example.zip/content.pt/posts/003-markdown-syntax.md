---
title: Guia de sintaxe Markdown
date: 2023-02-11
author: Equipe de autores MDFriday
description: Artigo de exemplo mostrando sintaxe básica Markdown e formatação para elementos HTML.
weight: 3
isStarred: true
---

## Cabeçalhos

Os seguintes elementos HTML `<h1>`—`<h6>` representam seis níveis de cabeçalhos de seção. `<h1>` é o nível de seção mais alto enquanto `<h6>` é o mais baixo.

# H1

## H2

### H3

#### H4

##### H5

###### H6

## Parágrafo

Xerum, quo qui aut unt expliquam qui dolut labo. Aque venitatiusda cum, voluptionse latur sitiae dolessi aut parist aut dollo enim qui voluptate ma dolestendit peritin re plis aut quas inctum laceat est volestemque commosa as cus endigna tectur, offic to cor sequas etum rerum idem sintibus eiur? Quianimin porecus evelectur, cum que nis nust voloribus ratem aut omnimi, sitatur? Quiatem. Nam, omnis sum am facea corem alique molestrunt et eos evelece arcillit ut aut eos eos nus, sin conecerem erum fuga. Ri oditatquam, ad quibus unda veliamenimin cusam et facea ipsamus es exerum sitate dolores editium rerore eost, temped molorro ratiae volorro te reribus dolorer sperchicium faceata tiustia prat.

Itatur? Quiatae cullecum rem ent aut odis in re eossequodi nonsequ idebis ne sapicia is sinveli squiatum, core et que aut hariosam ex eat.

## Imagem

Você pode usar a seguinte sintaxe para incluir uma imagem. O caminho da imagem deve ser relativo ao arquivo `index.md`.

```markdown
![Paisagem](1.jpg)
```

![Paisagem](1.jpg)

Você também pode incluir imagens de fontes externas.

```markdown
![Imagem](https://picsum.photos/600/300)
```

![Imagem](https://picsum.photos/600/300)

## Citações

O elemento blockquote representa conteúdo que é citado de outra fonte, opcionalmente com uma citação que deve estar dentro de um elemento `footer` ou `cite`, e opcionalmente com mudanças em linha como anotações e abreviações.

### Citação sem atribuição

> Você pode usar sintaxe Markdown dentro de uma citação, como **negrito**, _itálico_, [links](https://gohugo.io/), `código`.

### Citação com atribuição

> Não se comunique compartilhando memória, compartilhe memória comunicando-se.<br>
> — <cite>Rob Pike[^1]</cite>

[^1]: A citação acima é extraída da [palestra](https://www.youtube.com/watch?v=PAAkCSZUG1c) de Rob Pike durante o Gopherfest, 18 de novembro de 2015.

## Tabelas

### Markdown dentro de tabelas

| Itálico   | Negrito     | Código   |
| --------  | -------- | ------ |
| *itálico* | **negrito** | `código` |

## Blocos de código

### Bloco de código com crases

```html
<!doctype html>
<html lang="pt">
<head>
  <meta charset="utf-8">
  <title>Exemplo de documento HTML5</title>
</head>
<body>
  <p>Teste</p>
</body>
</html>
```

### Bloco de código indentado com quatro espaços

    <!doctype html>
    <html lang="pt">
    <head>
      <meta charset="utf-8">
      <title>Exemplo de documento HTML5</title>
    </head>
    <body>
      <p>Teste</p>
    </body>
    </html>

### Código inline

Use a crase para referenciar uma `variável` dentro de uma frase.

## Tipos de lista

### Lista ordenada

1. Primeiro item
2. Segundo item com algum `código` nele
3. Terceiro item

### Lista não ordenada

* Item da lista
* Outro item com algum `código` nele
* E outro item

### Lista aninhada

* Frutas
  * Maçã
  * Laranja
  * Banana
* Laticínios
  * Leite
  * Queijo

## Outros elementos — abbr, sub, sup, kbd, mark

<abbr title="Graphics Interchange Format">GIF</abbr> é um formato de imagem bitmap.

H<sub>2</sub>O

X<sup>n</sup> + Y<sup>n</sup> = Z<sup>n</sup>

Pressione <kbd>CTRL</kbd>+<kbd>ALT</kbd>+<kbd>Delete</kbd> para encerrar a sessão.

A maioria das <mark>salamandras</mark> são noturnas e caçam insetos, minhocas e outras pequenas criaturas.
