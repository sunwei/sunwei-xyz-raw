---
title: Comentários
date: 2023-05-02
description: Configurar comentários no tema awesome do blog MDFriday
comments: true
---

## Comentários

Este tema suporta comentários Disqus

## Habilitar comentários

Para habilitar comentários em determinados posts, defina o parâmetro `comments` como `true` no front matter.

    ```yaml
    ---
    title: Como habilitar índice
    date: 2023-05-02
    comments: true
    ---
    ```
