---
title: Sobre o MDFriday
date: 2025-10-10
author: Sun Wei
description: Introdução ao MDFriday
weight: 2
tags:
  - MDFriday
---

# Sobre o MDFriday

**MDFriday** — Apenas escreva. MDFriday dá vida às suas palavras.

É um sistema de publicação voltado para criadores que transforma suas notas do Obsidian em sites bonitos e prontos para compartilhar — completo com temas, shortcodes, SEO e hospedagem.

**Você se concentra na escrita. MDFriday cuida do resto.**

---

## 🧭 Nossa filosofia

> Concentre-se no seu conteúdo. Deixe a tecnologia ser invisível.

Durante a criação, frequentemente nos distraímos com:
- Configuração do site
- Estilização e layout
- Pipelines de implantação
- Configurações de SEO

Isso quebra o fluxo da criatividade.  
**MDFriday** visa eliminar todo atrito —  
para que um arquivo Markdown possa se tornar um site completo e publicado.

---

👨‍💻 **Autor: Sun Wei**  
Criador do MDFriday
> "Quero que os criadores apenas escrevam Markdown.  
> Deixem a construção, tematização e publicação comigo."
