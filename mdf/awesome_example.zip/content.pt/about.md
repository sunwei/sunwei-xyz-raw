---
title: Sobre
description: 'Saiba mais sobre Sun Wei, o criador do MDFriday.'
author: Sun Wei
---

# Sobre mim

Olá, eu sou **Sun Wei**,  
criador e desenvolvedor do **MDFriday**.

Minha missão é ajudar criadores a publicar seu trabalho facilmente —  
sem se distrair com implantação, design ou configuração.

**Você escreve Markdown. Eu cuido do resto.**

- 💡 Apaixonado por Markdown e design
- 🧠 Explorando IA e sistemas de conteúdo criativo
- 🧰 GitHub: [Plugin Obsidian Friday](https://github.com/mdfriday/obsidian-friday-plugin)
- 🌐 Site do projeto: [MDFriday](https://mdfriday.com)
