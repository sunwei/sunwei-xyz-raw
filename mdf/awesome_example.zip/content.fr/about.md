---
title: À propos
description: 'En savoir plus sur Sun Wei, le créateur de MDFriday.'
author: Sun Wei
---

# À propos de moi

Salut, je suis **Sun Wei**,  
créateur et développeur de **MDFriday**.

Ma mission est d'aider les créateurs à publier facilement leur travail —  
sans être distraits par le déploiement, le design ou la configuration.

**Vous écrivez en Markdown. Je m'occupe du reste.**

- 💡 Passionné par Markdown et le design
- 🧠 Explorer l'IA et les systèmes de contenu créatif
- 🧰 GitHub: [Plugin Obsidian Friday](https://github.com/mdfriday/obsidian-friday-plugin)
- 🌐 Site du projet: [MDFriday](https://mdfriday.com)
