---
title: "Accueil"

menu:
  nav:
    - title: "Accueil"
      url: "fr"
      weight: 1
    - title: "Articles"
      url: "fr/posts"
      weight: 2
    - title: "À propos"
      url: "fr/about.html"
      weight: 3

organization:
  name: "MDFriday Inc."
  description: "MDFriday est un éditeur Markdown puissant et une application de prise de notes."
  vision: "Concentrez-vous sur la création, MDFriday fait briller vos sites."
  website: "https://mdfriday.com"
  logo: "/images/logo.png"
  contact:
    email: "team@mdfriday.org"
    address: "À distance, Mondial"
    phone: "+1-202-555-0100"
  social:
    github: "https://github.com/mdfriday"
    twitter: "https://twitter.com/mdfriday"

author:
  name: "Sun Wei"
  description: "Créateur de MDFriday, passionné par Markdown, l'IA et la visualisation des connaissances."
  website: "https://sunwei.xyz"
  avatar: "avatar.png"
  contact:
    email: "sunwei@mdfriday.org"
    address: "À distance, Mondial"
    phone: "+1-202-555-0101"
  social:
    website: "https://yourwebsite.com"
    email: "mailto:youremail@domain.com"
    facebook: "https://facebook.com/username"
    github: "https://github.com/username"
    gitlab: "https://gitlab.com/username"
    bitbucket: "https://bitbucket.org/username"
    twitter: "https://twitter.com/username"
    reddit: "https://reddit.com/user/username"
    linkedin: "https://linkedin.com/in/username"
    xing: "https://www.xing.com/profile/username"
    stackoverflow: "https://stackoverflow.com/users/XXXXXXX/username"
    snapchat: "https://www.snapchat.com/add/username"
    instagram: "https://instagram.com/username"
    youtube: "https://youtube.com/user/username"
    soundcloud: "https://soundcloud.com/username"
    spotify: "https://open.spotify.com/user/username"
    bandcamp: "https://username.bandcamp.com"
    itchio: "https://username.itch.io"
    vk: "https://vk.com/username"
    paypal: "https://paypal.me/username"
    telegram: "https://t.me/username"
    500px: "https://500px.com/username"
    codepen: "https://codepen.io/username"
    mastodon: "https://mastodon.social/@username"   # besoin de remplacer selon l'instance
    kaggle: "https://kaggle.com/username"
    weibo: "https://weibo.com/username"
    slack: "https://username.slack.com"
    medium: "https://medium.com/@username"
    discord: "https://discord.gg/XXXXXXX"
    strava: "https://www.strava.com/athletes/userid"
    lastfm: "https://last.fm/user/username"
    bluesky: "https://bsky.app/profile/username"


---

Un thème MDFriday rapide et minimaliste avec support des modes clair et sombre, pour faire fonctionner un site personnel ou un blog.
