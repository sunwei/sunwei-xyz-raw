---
title: Commentaires
date: 2023-05-02
description: Configuration des commentaires dans le thème awesome du blog MDFriday
comments: true
---

## Commentaires

Ce thème prend en charge les commentaires Disqus

## Activer les commentaires

Pour activer les commentaires sur certains articles, définissez le paramètre `comments` à `true` dans le front matter.

    ```yaml
    ---
    title: Comment activer la table des matières
    date: 2023-05-02
    comments: true
    ---
    ```
