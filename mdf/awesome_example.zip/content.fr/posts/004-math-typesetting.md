---
author: Équipe d'auteurs Hugo
title: Composition mathématique - utiliser la notation mathématique dans les articles de blog
date: 2023-04-01
description: Un guide bref pour utiliser KaTeX
weight: 4
---

Dans cet exemple, nous utiliserons [KaTeX](https://katex.org/).

**Note :** La référence en ligne des
[Fonctions TeX supportées](https://katex.org/docs/supported.html) est une ressource utile.

### Exemples

- Mathématiques en bloc :

{{< katex display=true >}}
\varphi = 1+\frac{1} {1+\frac{1} {1+\frac{1} {1+\cdots} } }
{{< /katex >}}

- Mathématiques en ligne :

  Ceci est un polynôme en ligne : {{< katex >}}5x^2 + 2y -7{{< /katex >}}.
