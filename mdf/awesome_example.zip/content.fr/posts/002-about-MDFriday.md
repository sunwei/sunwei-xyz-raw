---
title: À propos de MDFriday
date: 2025-10-10
author: Sun Wei
description: Introduction à MDFriday
weight: 2
tags:
  - MDFriday
---

# À propos de MDFriday

**MDFriday** — Écrivez simplement. MDFriday donne vie à vos mots.

C'est un système de publication axé sur les créateurs qui transforme vos notes Obsidian en sites web beaux et prêts à partager — complet avec thèmes, shortcodes, SEO et hébergement.

**Vous vous concentrez sur l'écriture. MDFriday s'occupe du reste.**

---

## 🧭 Notre philosophie

> Concentrez-vous sur votre contenu. Laissez la technologie être invisible.

Pendant la création, nous sommes souvent distraits par :
- Configuration du site web
- Style et mise en page
- Pipelines de déploiement
- Configurations SEO

Cela brise le flux de créativité.  
**MDFriday** vise à éliminer toute friction —  
pour qu'un fichier Markdown puisse devenir un site web complet et publié.

---

👨‍💻 **Auteur : Sun Wei**  
Créateur de MDFriday
> "Je veux que les créateurs écrivent simplement en Markdown.  
> Laissez-moi m'occuper de la construction, des thèmes et de la publication."
