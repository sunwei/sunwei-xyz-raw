---
title: Guide de syntaxe Markdown
date: 2023-02-11
author: Équipe d'auteurs MDFriday
description: Article d'exemple présentant la syntaxe Markdown de base et le formatage des éléments HTML.
weight: 3
isStarred: true
---

## Titres

Les éléments HTML `<h1>`—`<h6>` suivants représentent six niveaux de titres de section. `<h1>` est le niveau de section le plus élevé tandis que `<h6>` est le plus bas.

# H1

## H2

### H3

#### H4

##### H5

###### H6

## Paragraphe

Xerum, quo qui aut unt expliquam qui dolut labo. Aque venitatiusda cum, voluptionse latur sitiae dolessi aut parist aut dollo enim qui voluptate ma dolestendit peritin re plis aut quas inctum laceat est volestemque commosa as cus endigna tectur, offic to cor sequas etum rerum idem sintibus eiur? Quianimin porecus evelectur, cum que nis nust voloribus ratem aut omnimi, sitatur? Quiatem. Nam, omnis sum am facea corem alique molestrunt et eos evelece arcillit ut aut eos eos nus, sin conecerem erum fuga. Ri oditatquam, ad quibus unda veliamenimin cusam et facea ipsamus es exerum sitate dolores editium rerore eost, temped molorro ratiae volorro te reribus dolorer sperchicium faceata tiustia prat.

Itatur? Quiatae cullecum rem ent aut odis in re eossequodi nonsequ idebis ne sapicia is sinveli squiatum, core et que aut hariosam ex eat.

## Image

Vous pouvez utiliser la syntaxe suivante pour inclure une image. Le chemin de l'image doit être relatif au fichier `index.md`.

```markdown
![Paysage](1.jpg)
```

![Paysage](1.jpg)

Vous pouvez également inclure des images provenant de sources externes.

```markdown
![Image](https://picsum.photos/600/300)
```

![Image](https://picsum.photos/600/300)

## Citations

L'élément blockquote représente du contenu qui est cité d'une autre source, optionnellement avec une citation qui doit être dans un élément `footer` ou `cite`, et optionnellement avec des changements en ligne tels que des annotations et des abréviations.

### Citation sans attribution

> Vous pouvez utiliser la syntaxe Markdown dans une citation, comme **gras**, _italique_, [liens](https://gohugo.io/), `code`.

### Citation avec attribution

> Ne communiquez pas en partageant la mémoire, partagez la mémoire en communiquant.<br>
> — <cite>Rob Pike[^1]</cite>

[^1]: La citation ci-dessus est extraite de la [conférence](https://www.youtube.com/watch?v=PAAkCSZUG1c) de Rob Pike lors du Gopherfest, le 18 novembre 2015.

## Tableaux

### Markdown dans les tableaux

| Italique   | Gras     | Code   |
| --------  | -------- | ------ |
| *italique* | **gras** | `code` |

## Blocs de code

### Bloc de code avec des backticks

```html
<!doctype html>
<html lang="fr">
<head>
  <meta charset="utf-8">
  <title>Exemple de document HTML5</title>
</head>
<body>
  <p>Test</p>
</body>
</html>
```

### Bloc de code indenté avec quatre espaces

    <!doctype html>
    <html lang="fr">
    <head>
      <meta charset="utf-8">
      <title>Exemple de document HTML5</title>
    </head>
    <body>
      <p>Test</p>
    </body>
    </html>

### Code en ligne

Utilisez le backtick pour faire référence à une `variable` dans une phrase.

## Types de listes

### Liste ordonnée

1. Premier élément
2. Deuxième élément avec du `code` dedans
3. Troisième élément

### Liste non ordonnée

* Élément de liste
* Un autre élément avec du `code` dedans
* Et un autre élément

### Liste imbriquée

* Fruits
  * Pomme
  * Orange
  * Banane
* Produits laitiers
  * Lait
  * Fromage

## Autres éléments — abbr, sub, sup, kbd, mark

<abbr title="Graphics Interchange Format">GIF</abbr> est un format d'image bitmap.

H<sub>2</sub>O

X<sup>n</sup> + Y<sup>n</sup> = Z<sup>n</sup>

Appuyez sur <kbd>CTRL</kbd>+<kbd>ALT</kbd>+<kbd>Suppr</kbd> pour terminer la session.

La plupart des <mark>salamandres</mark> sont nocturnes et chassent les insectes, les vers et autres petites créatures.
