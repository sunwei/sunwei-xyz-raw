---
title: Comment fonctionne MDFriday ?
date: 2025-10-10
author: Sun Wei
description: Guide d'utilisation de MDFriday dans Obsidian
weight: 1
tags:
  - MDFriday
---

**MDFriday** — Écrivez simplement. MDFriday donne vie à vos mots.

## L'histoire du thème Awesome

Awesome est pour les créateurs qui voient à travers le bruit —
ceux qui veulent que leurs mots parlent,
pas que leur design crie.

Simple. Propre. Précision mortelle.
C'est ça Awesome.

Comme *John Wick* - "Ouais, je pense que je suis de retour."

---

## ⚙️ Démarrage rapide

1. Ouvrez les **Plugins communautaires d'Obsidian**
2. Recherchez **Friday** et installez-le
3. Choisissez un thème depuis le panneau MDFriday
4. Téléchargez les notes d'exemple du thème
5. Clic droit sur une note → **Publier sur le Web**
6. Cliquez sur **Aperçu** pour le voir en direct localement

Une fois prévisualisé, modifiez les notes d'exemple avec votre propre contenu —
et vous avez votre site personnel !

Vous pouvez :
- Exporter le site statique et le télécharger n'importe où
- Ou configurer les paramètres cloud pour **publier directement** en un clic

---

## 🧩 Vue d'ensemble de l'architecture

MDFriday se compose de trois parties principales :

1. **Plugin Obsidian**
    - Fournit l'interface d'édition et de gestion des thèmes
    - Prend en charge l'aperçu, l'export et la publication
    - Permet aux utilisateurs d'installer des thèmes et des notes d'exemple en un clic

2. **Moteur de rendu de shortcodes**
    - Un système de template léger de style Hugo
    - Permet l'intégration de composants visuels personnalisés (cartes, galeries, etc.)
    - Implémenté en TypeScript, compatible multiplateforme

3. **Système de construction et publication**
    - Convertit Markdown + Shortcodes → site HTML statique
    - Applique automatiquement le thème sélectionné (Tailwind + moteur de template)
    - Exporte des fichiers prêts à héberger
    - Publication cloud optionnelle (Cloudflare / GitHub Pages / personnalisé)

---

## 🧠 Flux de travail

1. **Écrire en Markdown**  
   Créer et modifier des notes dans Obsidian — shortcodes inclus.

2. **Choisir un thème**  
   Chaque thème contient des templates, des notes d'exemple et des ressources de style.  
   Les thèmes sont entièrement personnalisables et faciles à prévisualiser.

3. **Aperçu et construction**  
   Cliquez sur **Aperçu** pour voir votre site localement.  
   MDFriday rend Markdown + Shortcodes + Thème de manière transparente.

4. **Publier**
    - Exporter le site statique et le télécharger n'importe où
    - Ou configurer les identifiants cloud pour une publication en un clic
    - Inclut automatiquement les balises méta SEO et les données OpenGraph

---

## 🔧 Stack technique et principes de design

| Module | Technologie | Principe de design |
|--------|-------------|------------------|
| Éditeur | Obsidian | Création centralisée et sans distraction |
| Moteur de rendu | TypeScript (compatible `text/template`) | Cohérence et extensibilité |
| Stylisation | Tailwind CSS | Minimal et thématisable |
| Construction | Node.js / ESBuild | Rapide et modulaire |
| Déploiement | Cloudflare / GitHub Pages / Local | Flexible et contrôlé par l'utilisateur |

---

## 🪄 Tout commence avec Markdown

MDFriday ne nécessite aucune nouvelle syntaxe ou outil.  
Chaque site commence par un simple fichier `.md`.  
Les thèmes définissent **l'apparence**,  
Les shortcodes définissent **la sensation**.

> ✨ En résumé :  
> **Écrire Markdown → Rendre → Construire → Publier**  
> Pas de code. Pas de config. Pas de distractions.

---

## 👨‍💻 Un mot de l'auteur

> "MDFriday est construit pour grandir avec les créateurs —  
> d'une seule note à un site de marque personnelle.  
> Je veux vous aider à transformer votre contenu en actifs numériques."
>
> — Sun Wei
