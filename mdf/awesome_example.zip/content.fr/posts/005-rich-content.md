---
author: Équipe d'auteurs Hugo
title: Contenu riche
date: 2023-02-09
description: Une brève description des shortcodes Hugo
weight: 5
---

Hugo est livré avec plusieurs [Shortcodes intégrés](https://gohugo.io/content-management/shortcodes/#use-hugos-built-in-shortcodes) pour le contenu riche, ainsi qu'une [Configuration de confidentialité](https://gohugo.io/about/hugo-and-gdpr/) et un ensemble de shortcodes simples qui permettent des versions statiques et sans JS de diverses intégrations de médias sociaux.
<!--more-->
---

## Shortcode YouTube avec confidentialité renforcée

{{< youtube ZJthWmvUzzc />}}

<br>

---

## Shortcode Twitter simple

{{< x user="DesignReviewed" id="1085870671291310081" />}}

<br>

---

## Shortcode Vimeo simple

{{< vimeo 48912912 />}}
