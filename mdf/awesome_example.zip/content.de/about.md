---
title: Über uns
description: 'Erfahren Sie mehr über Sun Wei, den Schöpfer von MDFriday.'
author: Sun Wei
---

# Über mich

Hallo, ich bin **Sun Wei**,  
Schöpfer und Entwickler von **MDFriday**.

Meine Mission ist es, Kreativen zu helfen, ihre Arbeit einfach zu veröffentlichen —  
ohne sich von Deployment, Design oder Konfiguration ablenken zu lassen.

**Sie schreiben Markdown. Ich kümmere mich um den Rest.**

- 💡 Leidenschaftlich für Markdown und Design
- 🧠 Erforschung von KI und kreativen Content-Systemen
- 🧰 GitHub: [Obsidian Friday Plugin](https://github.com/mdfriday/obsidian-friday-plugin)
- 🌐 Projekt-Website: [MDFriday](https://mdfriday.com)
