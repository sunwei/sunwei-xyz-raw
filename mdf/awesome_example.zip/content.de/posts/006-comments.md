---
title: Kommentare
date: 2023-05-02
description: Kommentare im MDFriday Blog Awesome Theme einrichten
comments: true
---

## Kommentare

Dieses Theme unterstützt Disqus-Kommentare

## Kommentare aktivieren

Um Kommentare bei bestimmten Posts zu aktivieren, setzen Sie den Parameter `comments` im Front Matter auf `true`.

    ```yaml
    ---
    title: Wie man das Inhaltsverzeichnis aktiviert
    date: 2023-05-02
    comments: true
    ---
    ```
