---
title: Wie funktioniert MDFriday?
date: 2025-10-10
author: Sun Wei
description: Leitfaden zur Verwendung von MDFriday in Obsidian
weight: 1
tags:
  - MDFriday
---

**MDFriday** — Schreiben Sie einfach. MDFriday erweckt es zum Leben.

## Die Awesome Theme Geschichte

Awesome ist für Kreative, die durch den Lärm sehen —
diejenigen, die wollen, dass ihre Worte sprechen,
nicht dass ihr Design schreit.

Einfach. Sauber. Tödlich präzise.
Das ist Awesome.

Wie *John Wick* - "Ja, ich denke, ich bin zurück."

---

## ⚙️ Schnellstart

1. Öffnen Sie **Obsidians Community-Plugins**
2. Suchen Sie nach **Friday** und installieren Sie es
3. Wählen Sie ein Theme aus dem MDFriday-Panel
4. Laden Sie die Beispielnotizen des Themes herunter
5. Rechtsklick auf eine Notiz → **Im Web veröffentlichen**
6. Klicken Sie auf **Vorschau**, um es lokal live zu sehen

Nach der Vorschau bearbeiten Sie die Beispielnotizen mit Ihrem eigenen Inhalt —
und Sie haben Ihre persönliche Website!

Sie können:
- Die statische Website exportieren und überall hochladen
- Oder Cloud-Einstellungen konfigurieren, um **direkt mit einem Klick zu veröffentlichen**

---

## 🧩 Architektur-Überblick

MDFriday besteht aus drei Hauptteilen:

1. **Obsidian Plugin**
    - Bietet die Bearbeitungs- und Theme-Management-Oberfläche
    - Unterstützt Vorschau, Export und Veröffentlichung
    - Ermöglicht Benutzern, Themes und Beispielnotizen mit einem Klick zu installieren

2. **Shortcode-Rendering-Engine**
    - Ein leichtgewichtiges Hugo-ähnliches Template-System
    - Ermöglicht die Einbettung von benutzerdefinierten visuellen Komponenten (Karten, Galerien, etc.)
    - In TypeScript implementiert, plattformübergreifend kompatibel

3. **Build- und Veröffentlichungssystem**
    - Konvertiert Markdown + Shortcodes → statische HTML-Website
    - Wendet automatisch das ausgewählte Theme an (Tailwind + Template-Engine)
    - Exportiert hosting-bereite Dateien
    - Optionale Cloud-Veröffentlichung (Cloudflare / GitHub Pages / benutzerdefiniert)

---

## 🧠 Arbeitsablauf

1. **Markdown schreiben**  
   Notizen in Obsidian erstellen und bearbeiten — Shortcodes inklusive.

2. **Ein Theme wählen**  
   Jedes Theme enthält Templates, Beispielnotizen und Style-Assets.  
   Themes sind vollständig anpassbar und einfach zu betrachten.

3. **Vorschau & Build**  
   Klicken Sie auf **Vorschau**, um Ihre Website lokal zu sehen.  
   MDFriday rendert Markdown + Shortcodes + Theme nahtlos.

4. **Veröffentlichen**
    - Die statische Website exportieren und überall hochladen
    - Oder Cloud-Anmeldedaten für Ein-Klick-Veröffentlichung konfigurieren
    - Enthält automatisch SEO-Meta-Tags und OpenGraph-Daten

---

## 🔧 Tech Stack und Design-Prinzipien

| Modul | Technologie | Design-Prinzip |
|--------|-------------|------------------|
| Editor | Obsidian | Zentralisierte, ablenkungsfreie Erstellung |
| Renderer | TypeScript (`text/template` kompatibel) | Konsistenz und Erweiterbarkeit |
| Styling | Tailwind CSS | Minimal und themefähig |
| Build | Node.js / ESBuild | Schnell und modular |
| Deploy | Cloudflare / GitHub Pages / Lokal | Flexibel und benutzerkontrolliert |

---

## 🪄 Alles beginnt mit Markdown

MDFriday erfordert keine neue Syntax oder Tools.  
Jede Website beginnt mit einer einfachen `.md`-Datei.  
Themes definieren **das Aussehen**,  
Shortcodes definieren **das Gefühl**.

> ✨ Zusammenfassung:  
> **Markdown schreiben → Rendern → Bauen → Veröffentlichen**  
> Kein Code. Keine Konfiguration. Keine Ablenkungen.

---

## 👨‍💻 Ein Wort vom Autor

> "MDFriday ist gebaut, um mit Kreativen zu wachsen —  
> von einer einzelnen Notiz zu einer persönlichen Marken-Website.  
> Ich möchte Ihnen helfen, Ihren Inhalt in digitale Assets zu verwandeln."
>
> — Sun Wei
