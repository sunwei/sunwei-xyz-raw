---
title: Markdown-Syntax-Leitfaden
date: 2023-02-11
author: MDFriday Autoren-Team
description: Beispielartikel, der grundlegende Markdown-Syntax und Formatierung für HTML-Elemente zeigt.
weight: 3
isStarred: true
---

## Überschriften

Die folgenden HTML `<h1>`—`<h6>` Elemente repräsentieren sechs Ebenen von Abschnittsüberschriften. `<h1>` ist die höchste Abschnittsebene, während `<h6>` die niedrigste ist.

# H1

## H2

### H3

#### H4

##### H5

###### H6

## Absatz

Xerum, quo qui aut unt expliquam qui dolut labo. Aque venitatiusda cum, voluptionse latur sitiae dolessi aut parist aut dollo enim qui voluptate ma dolestendit peritin re plis aut quas inctum laceat est volestemque commosa as cus endigna tectur, offic to cor sequas etum rerum idem sintibus eiur? Quianimin porecus evelectur, cum que nis nust voloribus ratem aut omnimi, sitatur? Quiatem. Nam, omnis sum am facea corem alique molestrunt et eos evelece arcillit ut aut eos eos nus, sin conecerem erum fuga. Ri oditatquam, ad quibus unda veliamenimin cusam et facea ipsamus es exerum sitate dolores editium rerore eost, temped molorro ratiae volorro te reribus dolorer sperchicium faceata tiustia prat.

Itatur? Quiatae cullecum rem ent aut odis in re eossequodi nonsequ idebis ne sapicia is sinveli squiatum, core et que aut hariosam ex eat.

## Bild

Sie können die folgende Syntax verwenden, um ein Bild einzufügen. Der Pfad des Bildes sollte relativ zur `index.md`-Datei sein.

```markdown
![Landschaft](1.jpg)
```

![Landschaft](1.jpg)

Sie können auch Bilder aus externen Quellen einbinden.

```markdown
![Bild](https://picsum.photos/600/300)
```

![Bild](https://picsum.photos/600/300)

## Blockzitate

Das Blockquote-Element repräsentiert Inhalt, der aus einer anderen Quelle zitiert wird, optional mit einer Zitation, die in einem `footer`- oder `cite`-Element stehen muss, und optional mit Inline-Änderungen wie Anmerkungen und Abkürzungen.

### Blockzitat ohne Zuordnung

> Sie können Markdown-Syntax innerhalb eines Blockzitats verwenden, wie **fett**, _kursiv_, [Links](https://gohugo.io/), `Code`.

### Blockzitat mit Zuordnung

> Kommunizieren Sie nicht durch das Teilen von Speicher, teilen Sie Speicher durch Kommunikation.<br>
> — <cite>Rob Pike[^1]</cite>

[^1]: Das obige Zitat ist aus Rob Pikes [Vortrag](https://www.youtube.com/watch?v=PAAkCSZUG1c) während des Gopherfest am 18. November 2015 entnommen.

## Tabellen

### Markdown innerhalb von Tabellen

| Kursiv   | Fett     | Code   |
| --------  | -------- | ------ |
| *kursiv* | **fett** | `code` |

## Code-Blöcke

### Code-Block mit Backticks

```html
<!doctype html>
<html lang="de">
<head>
  <meta charset="utf-8">
  <title>Beispiel HTML5-Dokument</title>
</head>
<body>
  <p>Test</p>
</body>
</html>
```

### Code-Block mit vier Leerzeichen eingerückt

    <!doctype html>
    <html lang="de">
    <head>
      <meta charset="utf-8">
      <title>Beispiel HTML5-Dokument</title>
    </head>
    <body>
      <p>Test</p>
    </body>
    </html>

### Inline-Code

Verwenden Sie das Backtick, um auf eine `Variable` innerhalb eines Satzes zu verweisen.

## Listen-Typen

### Geordnete Liste

1. Erstes Element
2. Zweites Element mit etwas `Code` darin
3. Drittes Element

### Ungeordnete Liste

* Listenelement
* Ein weiteres Element mit etwas `Code` darin
* Und noch ein Element

### Verschachtelte Liste

* Obst
  * Apfel
  * Orange
  * Banane
* Milchprodukte
  * Milch
  * Käse

## Andere Elemente — abbr, sub, sup, kbd, mark

<abbr title="Graphics Interchange Format">GIF</abbr> ist ein Bitmap-Bildformat.

H<sub>2</sub>O

X<sup>n</sup> + Y<sup>n</sup> = Z<sup>n</sup>

Drücken Sie <kbd>STRG</kbd>+<kbd>ALT</kbd>+<kbd>Entf</kbd>, um die Sitzung zu beenden.

Die meisten <mark>Salamander</mark> sind nachtaktiv und jagen Insekten, Würmer und andere kleine Kreaturen.
