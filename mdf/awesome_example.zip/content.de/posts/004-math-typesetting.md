---
author: Hugo Autoren-Team
title: Mathematischer Schriftsatz - mathematische Notation in Blog-Posts verwenden
date: 2023-04-01
description: Eine kurze Anleitung zur Verwendung von KaTeX
weight: 4
---

In diesem Beispiel verwenden wir [KaTeX](https://katex.org/).

**Hinweis:** Die Online-Referenz der
[Unterstützten TeX-Funktionen](https://katex.org/docs/supported.html) ist eine hilfreiche Ressource.

### Beispiele

- Block-Mathematik:

{{< katex display=true >}}
\varphi = 1+\frac{1} {1+\frac{1} {1+\frac{1} {1+\cdots} } }
{{< /katex >}}

- Inline-Mathematik:

  Dies ist ein Inline-Polynom: {{< katex >}}5x^2 + 2y -7{{< /katex >}}.
