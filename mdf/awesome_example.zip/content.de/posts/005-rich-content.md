---
author: Hugo Autoren-Team
title: Rich Content
date: 2023-02-09
description: Eine kurze Beschreibung von Hugo Shortcodes
weight: 5
---

Hugo kommt mit mehreren [eingebauten Shortcodes](https://gohugo.io/content-management/shortcodes/#use-hugos-built-in-shortcodes) für rich content, zusammen mit einer [Datenschutz-Konfiguration](https://gohugo.io/about/hugo-and-gdpr/) und einem Set einfacher Shortcodes, die statische und JS-freie Versionen verschiedener Social-Media-Einbettungen ermöglichen.
<!--more-->
---

## YouTube Datenschutz-erweiterter Shortcode

{{< youtube ZJthWmvUzzc />}}

<br>

---

## Twitter einfacher Shortcode

{{< x user="DesignReviewed" id="1085870671291310081" />}}

<br>

---

## Vimeo einfacher Shortcode

{{< vimeo 48912912 />}}
