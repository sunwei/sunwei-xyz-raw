---
title: Über MDFriday
date: 2025-10-10
author: Sun Wei
description: Einführung in MDFriday
weight: 2
tags:
  - MDFriday
---

# Über MDFriday

**MDFriday** — Schreiben Sie einfach. MDFriday erweckt es zum Leben.

Es ist ein kreativ-orientiertes Veröffentlichungssystem, das Ihre Obsidian-Notizen in schöne, teilbare Websites verwandelt — komplett mit Themes, Shortcodes, SEO und Hosting.

**Sie konzentrieren sich auf das Schreiben. MDFriday kümmert sich um den Rest.**

---

## 🧭 Unsere Philosophie

> Konzentrieren Sie sich auf Ihren Inhalt. Lassen Sie die Technologie unsichtbar sein.

Während der Erstellung werden wir oft abgelenkt durch:
- Website-Setup
- Styling und Layout
- Deployment-Pipelines
- SEO-Konfigurationen

Das unterbricht den Fluss der Kreativität.  
**MDFriday** zielt darauf ab, alle Reibung zu beseitigen —  
damit eine Markdown-Datei zu einer vollständigen, veröffentlichten Website werden kann.

---

👨‍💻 **Autor: Sun Wei**  
Schöpfer von MDFriday
> "Ich möchte, dass Kreative einfach nur Markdown schreiben.  
> Das Bauen, Thematisieren und Veröffentlichen überlassen Sie mir."
