---
title: "Startseite"

menu:
  nav:
    - title: "Startseite"
      url: "de"
      weight: 1
    - title: "Artikel"
      url: "de/posts"
      weight: 2
    - title: "Über uns"
      url: "de/about.html"
      weight: 3

organization:
  name: "MDFriday Inc."
  description: "MDFriday ist ein mächtiger Markdown-Editor und Notizen-App."
  vision: "Konzentrieren Sie sich auf das Erstellen, MDFriday lässt Ihre Websites glänzen."
  website: "https://mdfriday.com"
  logo: "/images/logo.png"
  contact:
    email: "team@mdfriday.org"
    address: "Remote, Global"
    phone: "+1-202-555-0100"
  social:
    github: "https://github.com/mdfriday"
    twitter: "https://twitter.com/mdfriday"

author:
  name: "Sun Wei"
  description: "Schöpfer von MDFriday, leidenschaftlich für Markdown, KI und Wissensvisualisierung."
  website: "https://sunwei.xyz"
  avatar: "avatar.png"
  contact:
    email: "sunwei@mdfriday.org"
    address: "Remote, Global"
    phone: "+1-202-555-0101"
  social:
    website: "https://yourwebsite.com"
    email: "mailto:youremail@domain.com"
    facebook: "https://facebook.com/username"
    github: "https://github.com/username"
    gitlab: "https://gitlab.com/username"
    bitbucket: "https://bitbucket.org/username"
    twitter: "https://twitter.com/username"
    reddit: "https://reddit.com/user/username"
    linkedin: "https://linkedin.com/in/username"
    xing: "https://www.xing.com/profile/username"
    stackoverflow: "https://stackoverflow.com/users/XXXXXXX/username"
    snapchat: "https://www.snapchat.com/add/username"
    instagram: "https://instagram.com/username"
    youtube: "https://youtube.com/user/username"
    soundcloud: "https://soundcloud.com/username"
    spotify: "https://open.spotify.com/user/username"
    bandcamp: "https://username.bandcamp.com"
    itchio: "https://username.itch.io"
    vk: "https://vk.com/username"
    paypal: "https://paypal.me/username"
    telegram: "https://t.me/username"
    500px: "https://500px.com/username"
    codepen: "https://codepen.io/username"
    mastodon: "https://mastodon.social/@username"   # muss je nach Instanz ersetzt werden
    kaggle: "https://kaggle.com/username"
    weibo: "https://weibo.com/username"
    slack: "https://username.slack.com"
    medium: "https://medium.com/@username"
    discord: "https://discord.gg/XXXXXXX"
    strava: "https://www.strava.com/athletes/userid"
    lastfm: "https://last.fm/user/username"
    bluesky: "https://bsky.app/profile/username"


---

Ein schnelles, minimalistisches MDFriday-Theme mit Unterstützung für helle und dunkle Modi, zum Betreiben einer persönlichen Website oder eines Blogs.
