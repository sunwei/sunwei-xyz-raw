---
title: 关于
description: '了解更多关于孙伟，MDFriday 的创造者。'
author: 孙伟
---

# 关于我

你好，我是**孙伟**，  
**MDFriday** 的创造者和开发者。

我的使命是帮助创作者轻松发布他们的作品——  
不被部署、设计或配置所干扰。

**你写 Markdown，剩下的交给我。**

- 💡 热衷于 Markdown 和设计
- 🧠 探索 AI 和创意内容系统
- 🧰 GitHub: [Obsidian Friday 插件](https://github.com/mdfriday/obsidian-friday-plugin)
- 🌐 项目网站: [MDFriday](https://mdfriday.com)
