---
author: Hugo 作者团队
title: 富内容
date: 2023-02-09
description: Hugo 短代码的简要描述
weight: 5
---

Hugo 内置了几个用于富内容的[内置短代码](https://gohugo.io/content-management/shortcodes/#use-hugos-built-in-shortcodes)，以及[隐私配置](https://gohugo.io/about/hugo-and-gdpr/)和一组简单短代码，可以实现各种社交媒体嵌入的静态和无 JS 版本。
<!--more-->
---

## YouTube 隐私增强短代码

{{< youtube ZJthWmvUzzc />}}

<br>

---

## Twitter 简单短代码

{{< x user="DesignReviewed" id="1085870671291310081" />}}

<br>

---

## Vimeo 简单短代码

{{< vimeo 48912912 />}}
