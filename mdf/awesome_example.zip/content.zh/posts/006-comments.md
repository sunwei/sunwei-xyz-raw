---
title: 评论
date: 2023-05-02
description: 在 MDFriday 博客 awesome 主题中设置评论
comments: true
---

## 评论

此主题支持 Disqus 评论

## 启用评论

要在特定文章上启用评论，请在前言中将参数 `comments` 设置为 `true`。

    ```yaml
    ---
    title: 如何启用目录
    date: 2023-05-02
    comments: true
    ---
    ```
