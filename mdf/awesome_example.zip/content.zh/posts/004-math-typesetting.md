---
author: Hugo 作者团队
title: 数学排版 - 在博客文章中使用数学符号
date: 2023-04-01
description: 使用 KaTeX 的简要指南
weight: 4
---

在这个示例中，我们将使用 [KaTeX](https://katex.org/)。

**注意：** [支持的 TeX 函数](https://katex.org/docs/supported.html) 在线参考是一个有用的资源。

### 示例

- 块级数学公式：

{{< katex display=true >}}
\varphi = 1+\frac{1} {1+\frac{1} {1+\frac{1} {1+\cdots} } }
{{< /katex >}}

- 内联数学公式：

  这是一个内联多项式：{{< katex >}}5x^2 + 2y -7{{< /katex >}}.
