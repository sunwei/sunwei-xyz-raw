---
title: 关于 MDFriday
date: 2025-10-10
author: 孙伟
description: MDFriday 介绍
weight: 2
tags:
  - MDFriday
---

# 关于 MDFriday

**MDFriday** — 只管写作，MDFriday 让它焕发生机。

这是一个以创作者为先的发布系统，将你的 Obsidian 笔记转换为美观、可分享的网站——完整包含主题、短代码、SEO 和托管。

**你专注写作，MDFriday 处理其余一切。**

---

## 🧭 我们的理念

> 专注于你的内容。让技术变得无形。

在创作过程中，我们经常被以下事情分心：
- 网站设置
- 样式和布局
- 部署流水线
- SEO 配置

这些会打断创作的流程。  
**MDFriday** 旨在消除所有摩擦——  
让一个 Markdown 文件就能成为一个完整的、已发布的网站。

---

👨‍💻 **作者：孙伟**  
MDFriday 的创造者
> "我希望创作者只需写 Markdown。  
> 构建、主题化和发布就交给我吧。"
