---
title: Markdown 语法指南
date: 2023-02-11
author: MDFriday 作者团队
description: 展示基本 Markdown 语法和 HTML 元素格式的示例文章。
weight: 3
isStarred: true
---

## 标题

以下 HTML `<h1>`—`<h6>` 元素代表六个级别的章节标题。`<h1>` 是最高的章节级别，而 `<h6>` 是最低的。

# H1

## H2

### H3

#### H4

##### H5

###### H6

## 段落

Xerum，quo qui aut unt expliquam qui dolut labo。Aque venitatiusda cum，voluptionse latur sitiae dolessi aut parist aut dollo enim qui voluptate ma dolestendit peritin re plis aut quas inctum laceat est volestemque commosa as cus endigna tectur，offic to cor sequas etum rerum idem sintibus eiur？Quianimin porecus evelectur，cum que nis nust voloribus ratem aut omnimi，sitatur？Quiatem。Nam，omnis sum am facea corem alique molestrunt et eos evelece arcillit ut aut eos eos nus，sin conecerem erum fuga。Ri oditatquam，ad quibus unda veliamenimin cusam et facea ipsamus es exerum sitate dolores editium rerore eost，temped molorro ratiae volorro te reribus dolorer sperchicium faceata tiustia prat。

Itatur？Quiatae cullecum rem ent aut odis in re eossequodi nonsequ idebis ne sapicia is sinveli squiatum，core et que aut hariosam ex eat。

## 图片

你可以使用以下语法来包含图片。图片的路径应该相对于 `index.md` 文件。

```markdown
![风景](1.jpg)
```

![风景](1.jpg)

你也可以包含来自外部来源的图片。

```markdown
![图片](https://picsum.photos/600/300)
```

![图片](https://picsum.photos/600/300)

## 引用块

引用块元素表示从另一个来源引用的内容，可选择带有必须在 `footer` 或 `cite` 元素内的引用，以及可选择带有内联更改，如注释和缩写。

### 无属性的引用块

> 你可以在引用块中使用 Markdown 语法，如 **粗体**、_斜体_、[链接](https://gohugo.io/)、`代码`。

### 带属性的引用块

> 不要通过共享内存来通信，而要通过通信来共享内存。<br>
> — <cite>Rob Pike[^1]</cite>

[^1]: 上述引用摘录自 Rob Pike 在 2015 年 11 月 18 日 Gopherfest 期间的[演讲](https://www.youtube.com/watch?v=PAAkCSZUG1c)。

## 表格

### 表格中的 Markdown

| 斜体   | 粗体     | 代码   |
| --------  | -------- | ------ |
| *斜体* | **粗体** | `代码` |

## 代码块

### 使用反引号的代码块

```html
<!doctype html>
<html lang="zh">
<head>
  <meta charset="utf-8">
  <title>示例 HTML5 文档</title>
</head>
<body>
  <p>测试</p>
</body>
</html>
```

### 用四个空格缩进的代码块

    <!doctype html>
    <html lang="zh">
    <head>
      <meta charset="utf-8">
      <title>示例 HTML5 文档</title>
    </head>
    <body>
      <p>测试</p>
    </body>
    </html>

### 内联代码

使用反引号在句子中引用一个 `变量`。

## 列表类型

### 有序列表

1. 第一项
2. 第二项，其中包含一些 `代码`
3. 第三项

### 无序列表

* 列表项
* 另一个包含一些 `代码` 的项目
* 还有另一个项目

### 嵌套列表

* 水果
  * 苹果
  * 橙子
  * 香蕉
* 乳制品
  * 牛奶
  * 奶酪

## 其他元素 — abbr、sub、sup、kbd、mark

<abbr title="图形交换格式">GIF</abbr> 是一种位图图像格式。

H<sub>2</sub>O

X<sup>n</sup> + Y<sup>n</sup> = Z<sup>n</sup>

按 <kbd>CTRL</kbd>+<kbd>ALT</kbd>+<kbd>Delete</kbd> 结束会话。

大多数 <mark>蝾螈</mark> 是夜行性的，捕食昆虫、蠕虫和其他小生物。
