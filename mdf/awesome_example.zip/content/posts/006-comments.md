---
title: Comments
date: 2023-05-02
description: Setup comments in MDFriday blog awesome theme
comments: true
---

## Comments

This theme supports Disqus comments

## Enable comments

To enable Comments on certain posts set parameter `comments` to `true` in front matter.

    ```yaml
    ---
    title: How to enable table of content
    date: 2023-05-02
    comments: true
    ---
    ```
