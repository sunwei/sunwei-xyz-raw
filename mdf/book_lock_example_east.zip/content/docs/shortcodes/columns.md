# Columns

Columns help organize shorter pieces of content horizontally for readability.

## Example

```html
{{%/* columns [ratio="1:1"] [class="..."] */%}} <!-- begin columns block -->
# Left Content
Lorem markdownum insigne...

=== <!-- magic separator, between columns -->

# Mid Content
Lorem markdownum insigne...

=== <!-- magic separator, between columns -->

# Right Content
Lorem markdownum insigne...
{{%/* /columns */%}}
```

{{% columns %}}
### Left Content
Lorem markdownum insigne. Olympo signis Delphis! Retexi Nereius nova develat
stringit, frustra Saturnius uteroque inter! Oculis non ritibus Telethusa
protulit, sed sed aere valvis inhaesuro Pallas animam: qui _quid_, ignes.
Miseratus fonte Ditis conubia.

===

### Mid Content
Lorem markdownum insigne. Olympo signis Delphis! Retexi Nereius nova develat
stringit, frustra Saturnius uteroque inter!

===

### Right Content
Lorem markdownum insigne. Olympo signis Delphis! Retexi Nereius nova develat
stringit, frustra Saturnius uteroque inter! Oculis non ritibus Telethusa
protulit, sed sed aere valvis inhaesuro Pallas animam: qui _quid_, ignes.
Miseratus fonte Ditis conubia.
{{% /columns %}}

## Settings size ratio for columns

```html
{{%/* columns ratio="1:2" */%}} <!-- begin columns block -->

## x1 Column
Lorem markdownum insigne...

=== <!-- magic separator, between columns -->

## x2 Column
Lorem markdownum insigne...

{{%/* /columns */%}}
```

{{% columns ratio="1:2" %}}
### x1 Column
Lorem markdownum insigne. Olympo signis Delphis! Retexi Nereius nova develat
stringit, frustra Saturnius uteroque inter! Oculis non ritibus Telethusa
protulit, sed sed aere valvis inhaesuro Pallas animam: qui _quid_, ignes.
Miseratus fonte Ditis conubia.

===

### x2 Column
Lorem markdownum insigne. Olympo signis Delphis! Retexi Nereius nova develat
stringit, frustra Saturnius uteroque inter!

Lorem markdownum insigne. Olympo signis Delphis! Retexi Nereius nova develat
stringit, frustra Saturnius uteroque inter! Oculis non ritibus Telethusa
protulit, sed sed aere valvis inhaesuro Pallas animam: qui _quid_, ignes.
Miseratus fonte Ditis conubia.

{{% /columns %}}
